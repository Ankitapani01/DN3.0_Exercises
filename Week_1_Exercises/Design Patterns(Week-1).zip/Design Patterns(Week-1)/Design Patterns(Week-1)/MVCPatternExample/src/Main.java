public class Main {
    public static void main(String[] args) {
        Student student = new Student("Ankita Pani", "70", "A");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(student, view);
        controller.updateView();
        controller.setStudentName("Riddhi Agarwal");
        controller.setStudentGrade("B");
        controller.updateView();
    }
}
