public class Main {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("Ankita.jpeg");
        Image image2 = new ProxyImage("Anki.JPG");

        image1.display();
        System.out.println("");

        image1.display();
        System.out.println("");

        image2.display();
    }
}
